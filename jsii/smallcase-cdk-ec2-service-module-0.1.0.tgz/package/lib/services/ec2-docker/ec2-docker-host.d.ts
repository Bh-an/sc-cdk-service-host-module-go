import { aws_ec2 as ec2, aws_iam as iam, aws_kms as kms } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { NetworkAddressableServiceOutputs, PlatformServiceProps, ResolvedPlatformServiceIdentity, ServiceExposureKind } from '../../contracts/platform-service';
import { Ec2DockerServiceRuntimeProps, IngressRule } from './types';
interface Ec2DockerHostDefaults {
    readonly associatePublicIpAddress: boolean;
    readonly defaultIngressRules: IngressRule[];
    readonly exposureKind: ServiceExposureKind;
    readonly enableElasticIp: boolean;
}
export interface Ec2DockerHostProps extends PlatformServiceProps, Ec2DockerServiceRuntimeProps, Ec2DockerHostDefaults {
}
export interface Ec2DockerHostResources {
    readonly dataKey: kms.IKey;
    readonly dataMountPath: string;
    readonly dataVolumeDeviceName: string;
    readonly elasticIp?: ec2.CfnEIP;
    readonly instance: ec2.Instance;
    readonly role: iam.IRole;
    readonly securityGroup: ec2.ISecurityGroup;
    readonly serviceIdentity: ResolvedPlatformServiceIdentity;
    readonly serviceOutputs: NetworkAddressableServiceOutputs;
}
export interface ResolveEc2ServiceExposureOptions {
    readonly defaultExposureKind: ServiceExposureKind;
    readonly legacyAssociatePublicIpAddress: boolean;
    readonly legacyDefaultIngressRules: IngressRule[];
    readonly legacyEnableElasticIp: boolean;
    readonly privateVpcCidr: string;
    readonly publicPort: number;
    readonly requestedExposure?: Ec2DockerServiceRuntimeProps['exposure'];
}
export declare function resolveEc2ServiceExposure(options: ResolveEc2ServiceExposureOptions): Ec2DockerHostDefaults;
export declare function createEc2DockerHostResources(scope: Construct, props: Ec2DockerHostProps): Ec2DockerHostResources;
export {};
