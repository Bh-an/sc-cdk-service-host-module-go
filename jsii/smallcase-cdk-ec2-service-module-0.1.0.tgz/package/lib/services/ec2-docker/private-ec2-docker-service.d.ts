import { aws_ec2 as ec2, aws_iam as iam, aws_kms as kms } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { NetworkAddressableServiceOutputs, PlatformServiceProps, ResolvedPlatformServiceIdentity } from '../../contracts/platform-service';
import { Ec2DockerServiceRuntimeProps } from './types';
export interface PrivateEc2DockerServiceProps extends PlatformServiceProps, Ec2DockerServiceRuntimeProps {
}
export declare class PrivateEc2DockerService extends Construct {
    readonly dataKey: kms.IKey;
    readonly dataMountPath: string;
    readonly dataVolumeDeviceName: string;
    readonly elasticIp?: ec2.CfnEIP;
    readonly instance: ec2.Instance;
    readonly role: iam.IRole;
    readonly securityGroup: ec2.ISecurityGroup;
    readonly serviceIdentity: ResolvedPlatformServiceIdentity;
    readonly serviceOutputs: NetworkAddressableServiceOutputs;
    constructor(scope: Construct, id: string, props: PrivateEc2DockerServiceProps);
}
