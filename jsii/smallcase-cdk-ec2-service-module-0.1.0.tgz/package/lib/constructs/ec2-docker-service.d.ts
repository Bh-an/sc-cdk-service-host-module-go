import { aws_ec2 as ec2, aws_iam as iam, aws_kms as kms } from 'aws-cdk-lib';
import { Construct } from 'constructs';
export interface IngressRule {
    readonly cidr: string;
    readonly description?: string;
    readonly port?: number;
}
export interface Ec2DockerServiceProps {
    readonly allowedIngress?: IngressRule[];
    readonly bridgeCidr?: string;
    readonly bridgeIp?: string;
    readonly bridgeNetworkName?: string;
    readonly dataMountPath?: string;
    readonly dataVolumeDeviceName?: string;
    readonly dataVolumeSizeGiB?: number;
    readonly dockerImage: string;
    readonly enableElasticIp?: boolean;
    readonly instanceType?: ec2.InstanceType;
    readonly keyPair?: ec2.IKeyPair;
    readonly kmsKey?: kms.IKey;
    readonly machineImage?: ec2.IMachineImage;
    readonly nginxMainConfig?: string;
    readonly nginxRoutesConfig?: string;
    readonly publicPort?: number;
    readonly role?: iam.IRole;
    readonly rootVolumeSizeGiB?: number;
    readonly serviceName?: string;
    readonly servicePort?: number;
    readonly subnetSelection?: ec2.SubnetSelection;
    readonly vpc: ec2.IVpc;
}
export declare class Ec2DockerService extends Construct {
    readonly dataKey: kms.IKey;
    readonly dataMountPath: string;
    readonly dataVolumeDeviceName: string;
    readonly elasticIp?: ec2.CfnEIP;
    readonly instance: ec2.Instance;
    readonly role: iam.IRole;
    readonly securityGroup: ec2.SecurityGroup;
    constructor(scope: Construct, id: string, props: Ec2DockerServiceProps);
}
