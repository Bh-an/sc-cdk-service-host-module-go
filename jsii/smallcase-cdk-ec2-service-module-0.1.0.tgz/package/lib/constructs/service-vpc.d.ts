import { aws_ec2 as ec2 } from 'aws-cdk-lib';
import { Construct } from 'constructs';
export interface ServiceVpcProps {
    readonly cidr?: string;
    readonly maxAzs?: number;
    readonly publicSubnetMask?: number;
}
export declare class ServiceVpc extends Construct {
    readonly publicSubnetSelection: ec2.SubnetSelection;
    readonly vpc: ec2.Vpc;
    constructor(scope: Construct, id: string, props?: ServiceVpcProps);
}
