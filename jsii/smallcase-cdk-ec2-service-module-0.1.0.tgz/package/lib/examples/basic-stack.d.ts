import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
export declare class BasicAssignmentStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: cdk.StackProps);
}
