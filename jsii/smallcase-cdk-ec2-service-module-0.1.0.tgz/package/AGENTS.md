# Project Guidelines

## Commit Message Format

Use [Conventional Commits](https://www.conventionalcommits.org/):

```
type(scope): short description
```

- **Types:** `feat`, `fix`, `chore`, `docs`, `refactor`, `test`, `ci`
- **Scopes (optional):** `cdk`, `examples`, `test`, `docs`
- Subject line ≤ 72 chars, imperative mood, no trailing period
- Body is optional — use it for *why*, not *what*
- No `Co-Authored-By` AI attribution lines

**Examples:**
```
feat(cdk): add health check timeout prop to Ec2DockerService
fix(examples): correct VPC CIDR in shared-infra-stack
chore: update aws-cdk-lib peer dependency
```

## What to NEVER Commit

| Category | Examples |
|----------|---------|
| Secrets / credentials | `.env`, AWS keys, tokens |
| Node artifacts | `node_modules/`, `dist/`, `lib/`, `cdk.out/`, `.jsii`, `*.tgz` |
| Agent / AI tooling | `.claude/`, `CLAUDE.md`, `AGENTS.md`, `.kiro/` |
| Local setup & docs | `.setup/`, `project_docs/` |

## File Organization

This project uses a split between committed code and local-only files:

- **`project_docs/`** — project documentation (architecture decisions, dev workflow, API docs). Excluded from git.
- **`.setup/index.md`** — manifest listing paths to all agent files and project docs. Excluded from git.
- **Agent files** (`.claude/`, `.kiro/`, `CLAUDE.md`, `AGENTS.md`) — AI agent instructions and config. Excluded from git.

### Exclusion mechanism

All agent files, `project_docs/`, and `.setup/` are excluded via **`.git/info/exclude`**, NOT `.gitignore`.

`.git/info/exclude` is a local file that is never committed — it works identically to `.gitignore` but stays invisible to anyone cloning the repo.

**Rules:**
- The committed `.gitignore` must NEVER reference AI tool names (`.claude/`, `.kiro/`, `CLAUDE.md`, `AGENTS.md`)
- The committed `.gitignore` must NEVER reference `project_docs/` or `.setup/`
- When creating new agent config files, add them to `.git/info/exclude`
- When initializing a fresh clone, repopulate `.git/info/exclude` from `.setup/index.md`

## AI Hygiene

- No `Co-Authored-By` or AI attribution lines in commits
- No AI tool names in any committed file (`.gitignore`, source comments, README, etc.)
- All committed documentation must read as human-written — no generated boilerplate
- `.git/info/exclude` is the only mechanism for hiding local files; it is never committed

## Branching

- `main` is the only long-lived branch
- Feature branches: `feat/<short-description>`
- Fix branches: `fix/<short-description>`

## Pre-Commit Checks

```bash
npm run verify
```

## Commit Scope

- One logical change per commit — do not bundle unrelated work
- Do not amend pushed commits except to correct critical mistakes
