# Setup Index — cdk-ec2-service-module

## Agent / AI tooling (excluded via .git/info/exclude)

- `.claude/` — Claude Code config
- `.kiro/` — Kiro steering config
- `CLAUDE.md` — commit and coding guidelines
- `AGENTS.md` — agent instructions (cross-agent compat)

## Project docs (excluded via .git/info/exclude)

- `project_docs/README.md`
- `project_docs/API.md`
- `project_docs/DECISIONS.md`
- `project_docs/DEV.md`
- `project_docs/STATE.md`
