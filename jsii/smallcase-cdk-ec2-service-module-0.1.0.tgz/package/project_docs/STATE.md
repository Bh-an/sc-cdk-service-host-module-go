# Current State

## Summary

`cdk-ec2-service-module` is the active infra/devops evolution repo for the assignment-aligned service model.

It currently contains:

- shared caller-owned infrastructure contracts
- shared service identity and output contracts
- a public/default EC2 service variant
- a private/internal EC2 service variant
- a shared internal EC2 host/bootstrap helper path
- explicit exposure metadata and ingress-source controls
- operational controls for IAM and bootstrap behavior
- an in-repo consumer proof with ALB-backed private-service wiring
- a tracked consumer requirement that the app repo is a Go application repo

## Current Public Modules

### `Ec2DockerService`

- public/default operational posture
- module-managed Elastic IP by default
- public ingress on the configured listener port
- normalized outputs through `serviceOutputs`
- can now be switched to caller-managed exposure through additive exposure controls

### `PrivateEc2DockerService`

- private/internal operational posture
- no module-managed public endpoint
- no EIP by default
- VPC-internal ingress posture by default
- same identity/output contract shape as the public variant
- supports caller-managed ingress sources such as shared security groups

## Shared Public Contracts

- `ServiceInfrastructureProps`
- `PlatformServiceIdentity`
- `PlatformServiceProps`
- `ResolvedPlatformServiceIdentity`
- `PlatformServiceOutputs`
- `NetworkAddressableServiceOutputs`
- `ServiceExposureKind`
- `Ec2DockerServiceRuntimeProps`
- `IngressRule`

## Verification Status

Current local verification baseline:

```bash
npm run verify
```

Expected covered checks:

- TypeScript compile
- Jest tests
- jsii/Go packaging

Current tracked package version:

- `0.0.6`

## Git / Repo State

Important repo-management fact:

- git is initialized
- the repo now has a real tracked milestone history
- agent/docs local-only structure is configured correctly
- `.jsii` is now treated as generated output in `.gitignore`
- root package README is now tracked for jsii packaging
- core project files are tracked and the working tree can be clean

## Known Rough Edges

- local-only docs need to stay in sync with the tracked `0.0.5` state
- local-only docs need to stay in sync with the tracked `0.0.6` state
- consumer CI/CD integration is scaffolded, but real app deployment remains consumer-repo work
- the consumer app contract is now explicitly Go-oriented rather than app-language-agnostic
- the supported path is still Node 20 even if some shells may be on newer Node versions
