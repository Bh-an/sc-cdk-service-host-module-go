# Decisions

This file is local-only architecture history for `cdk-ec2-service-module`.

Use it when you need reasoning and chronology. Do not use it as the quick-start path.

## Current Defaults

- source of truth is TypeScript CDK code
- Go packaging remains part of the intended release path through `jsii`
- the module family plugs into caller-owned infrastructure
- the service model stays aligned to the original assignment
- current concrete variants are:
  - `Ec2DockerService`
  - `PrivateEc2DockerService`
- local verification baseline is Node 20 plus `npm run verify`
- `.jsii` is treated as generated repo output, not handwritten source
- tracked version baseline is now `0.0.4` with current consumer-proof state at `0.0.6`

## Decision 1: Preserve the assignment behavior as the implementation baseline

### Context

The starting point was a Terraform + Packer + EC2 assignment repo with a Go service behind Nginx, Docker on the host, encrypted volumes, and SSM-based access.

### Chosen Direction

Treat that deployed behavior as the source of truth for what the CDK repo should preserve.

### Impact

The CDK module family keeps the same service model even as infra/devops posture evolves.

## Decision 2: Build a separate reusable CDK repo instead of extending the Terraform repo in place

### Context

The assignment repo is a single delivery repo. The target direction was a reusable CDK module family.

### Chosen Direction

Create and evolve `cdk-ec2-service-module` as a separate repo rather than reshaping the Terraform repo in place.

### Impact

`ec2-assignment` remains the behavioral baseline; this repo becomes the active evolution path.

## Decision 3: Use TypeScript as the implementation source of truth with Go packaging intent

### Context

The target pattern is closer to smallcase’s CDK module repos, where TypeScript is primary and Go bindings are generated.

### Chosen Direction

Keep TypeScript as the implementation source of truth and package Go bindings through `jsii`.

### Impact

Public API design happens in TypeScript, but packaging success still matters as a verification gate.

## Decision 4: Plug into caller-owned infrastructure instead of owning base infra

### Context

A module-owned VPC/environment model would force consumers into infrastructure choices they may already have solved elsewhere.

### Chosen Direction

Require caller-owned VPC and subnet selection, with optional caller-supplied SG, IAM role, KMS key, and EC2 key pair.

### Impact

The module family stays composable inside existing infrastructure stacks.

## Decision 5: Split by reusable behavior, not by Terraform file categories

### Context

The Terraform assignment used numbered files for network, IAM, KMS, compute, and security. That does not map well to public CDK boundaries.

### Chosen Direction

Use service-level contracts and helper extraction instead of mirroring Terraform file categories.

### Impact

The public API stays compact while internal helper boundaries can evolve as real reuse appears.

## Decision 6: Introduce shared service identity and outputs before adding another service posture

### Context

After the first EC2 module existed, the main missing layer was a shared public contract future modules could implement consistently.

### Chosen Direction

Add:

- `PlatformServiceIdentity`
- resolved service identity
- normalized service outputs

before adding a second concrete module.

### Impact

Multiple service variants can now present a consistent consumer surface.

## Decision 7: Expand on the infra/devops axis, not the application/runtime axis

### Context

The service itself should stay close to the assignment. Extra work should improve provisioning posture, reuse, packaging, and ops behavior rather than inventing a different runtime.

### Chosen Direction

Use the same EC2 + Docker + Nginx service shape for all further expansion.

### Impact

Future work stays focused on operational posture and reusable infra behavior.

## Decision 8: Add a private/internal operational sibling instead of a new runtime family

### Context

The repo needed to prove reuse with a second concrete module without drifting away from the assignment.

### Chosen Direction

Add `PrivateEc2DockerService` as an operational sibling to `Ec2DockerService`.

### Impact

The repo now has two concrete variants of the same service model:

- public/default
- private/internal

## Decision 9: Extract a shared internal EC2 host/bootstrap path

### Context

With two EC2 service variants, duplicating IAM/KMS/SG resolution, instance defaults, and user-data rendering would make the repo harder to evolve safely.

### Chosen Direction

Extract shared internal helpers for:

- resource resolution
- block-device and instance defaults
- bootstrap rendering
- normalized output construction

### Impact

Both public and private variants now share one internal implementation path while keeping the public API at the service-module level.

## Decision 10: Treat repo normalization as the next planning prerequisite

### Context

The code and local docs now describe a real v0.0.4 state, but the repo itself is still young and needs a clean tracked baseline.

### Chosen Direction

Normalize git state and local documentation before planning the next feature wave.

### Impact

This led to a milestone-based tracked history instead of a one-shot compacted baseline.

## Decision 11: Add hardening through exposure controls and operational hooks, not through a new runtime

### Context

The next useful feature wave needed to improve network posture and operational control without drifting away from the assignment service model.

### Chosen Direction

Additive hardening is now expressed through:

- exposure metadata in normalized outputs
- ingress rules that can be CIDR-based or security-group-based
- operational controls for IAM policy extension, detailed monitoring, and bootstrap hooks

### Impact

Consumers can now model caller-managed ingress and stronger host controls while keeping the same EC2 + Docker + Nginx service shape.

## Decision 12: Reconstruct tracked history to match real milestones

### Context

The repo had reached a real implementation state before it had any commits, and the baseline needed to be tracked without flattening the work into one synthetic initial commit.

### Chosen Direction

Create a tracked milestone sequence that reflects the actual work already completed:

- scaffold
- tracked docs/setup
- shared service family baseline
- hardening wave
- consumer CI/CD scaffolding

### Impact

The repo history now matches the shape of the work and supports future versioned development from a clean `0.0.4` and `0.0.5` base.

## Decision 13: Keep app CI/CD as consumer scaffolding, not module-owned deployment

### Context

The module repo needs to tie into how an app would be built and deployed, but it should not become the app deployment repo itself.

### Chosen Direction

Add tracked consumer-facing CI/CD guidance and a reference workflow template, while keeping real image build/push and deploy execution in the consumer app repo.

### Impact

This repo now documents and scaffolds app integration without taking ownership of app release pipelines.

## Decision 14: Prove consumption in-repo before moving the app into a separate consumer repo

### Context

The next gap after CI/CD scaffolding was proving that a consumer stack can really wire both public and private service postures correctly.

### Chosen Direction

Add an in-repo consumer proof that synthesizes:

- a direct public/default service
- a private service in private subnets
- a caller-managed ALB fronting the private service

The private service still keeps host-level Nginx, with the ALB forwarding to the Nginx listener port on the instance.

### Impact

The repo now proves the intended consumer integration path without yet moving the real app into a separate consumer repo.

## Decision 15: Make the consumer app a Go requirement

### Context

The module is TS-to-Go for construct consumption, and the assignment application itself is Go. The consumer story should be explicit instead of implying any arbitrary application runtime.

### Chosen Direction

Document the expected consumer as a Go application repo:

- the app source is Go
- the consumer deploy workflow validates the Go app before building the image
- the module remains TypeScript source with jsii-generated Go bindings

### Impact

The consumer CI/CD story is now aligned with the assignment application and with the intended TS-to-Go module usage.
