# API

This is the local API orientation note for `cdk-ec2-service-module`.

It is not meant to replace generated jsii docs. Use it when you need a quick view of the current exported surface without regenerating docs.

## Current Exports

From `src/index.ts`, the repo currently exports:

- `PlatformServiceIdentity`
- `ServiceInfrastructureProps`
- `PlatformServiceProps`
- `ResolvedPlatformServiceIdentity`
- `PlatformServiceOutputs`
- `NetworkAddressableServiceOutputs`
- `ServiceExposureKind`
- `mergeTags`
- `applyTags`
- `resolveServiceIdentity`
- `buildResourceName`
- `Ec2DockerService`
- `PrivateEc2DockerService`
- `Ec2DockerServiceRuntimeProps`
- `IngressRule`

## Current Public Shape

### Shared contracts

The shared contracts define:

- caller-owned infrastructure inputs
- service identity and naming resolution
- merged tag behavior
- normalized service outputs
- exposure-kind metadata for network-facing services

These are the stable layer future service modules should follow.

### Concrete modules

The repo currently ships two concrete modules for the same assignment-aligned service model:

- `Ec2DockerService`
  - public/default operational posture
  - Elastic IP by default
- `PrivateEc2DockerService`
  - private/internal operational posture
  - no public endpoint by default

Both are intended to be consumed from an external stack or app-infra repo, not from a deployment workflow owned by this module repo.

The repo now also includes an in-repo consumer proof example showing:

- a direct public/default service
- an ALB-backed private service

### Runtime props

`Ec2DockerServiceRuntimeProps` captures runtime and host-bootstrap settings such as:

- Docker image
- ingress rules
- exposure controls
- operational controls
- service and public port selection
- block-device sizing
- Docker bridge settings
- optional custom Nginx config fragments

## Consumer Integration Note

Tracked consumer integration guidance now lives in:

- `README.md`
- `docs/consumer-cicd.md`
- `.github/workflow-templates/consumer-app-deploy.yml`

Use those when wiring this package into an app repo’s build and deploy flow.

Use `examples/consumer-proof-stack.ts` when you need the concrete infrastructure composition pattern.

For current project assumptions, read those consumer materials as Go-app integration guidance, not generic application guidance.

## Generated API Docs

If you want generated docs from the TypeScript source, run:

```bash
npm run docgen
```

That should regenerate the formal API reference from the current jsii source.
