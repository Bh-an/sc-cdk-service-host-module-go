# cdk-ec2-service-module

`cdk-ec2-service-module` is the active infrastructure-evolution repo for the assignment-aligned service model. It provides reusable CDK modules that plug into caller-owned infrastructure while preserving the same core runtime shape:

- EC2 host
- Dockerized Go app
- host-level Nginx
- encrypted storage
- SSM-first access posture

## Current Service Family

The repo currently exposes two operational variants of the same service:

- `Ec2DockerService`
  - public/default posture
  - module-managed Elastic IP by default
  - public ingress on the configured listener port
- `PrivateEc2DockerService`
  - private/internal posture
  - no module-managed public endpoint
  - ingress intended for VPC-internal or caller-controlled ranges

Both variants share:

- `ServiceInfrastructureProps`
- `PlatformServiceIdentity`
- `PlatformServiceProps`
- `ResolvedPlatformServiceIdentity`
- `PlatformServiceOutputs` / `NetworkAddressableServiceOutputs`
- `ServiceExposureKind`
- `Ec2DockerServiceRuntimeProps` / `IngressRule`

The current hardening wave adds:

- explicit exposure metadata through `serviceOutputs.exposureKind`
- ingress rules that can target either CIDRs or source security groups
- operational controls for IAM policy extension, detailed monitoring, and bootstrap command hooks
- an in-repo consumer proof that validates both public/default and ALB-backed private consumption paths
- a consumer assumption that the app repo itself is a Go application repo

## What The Caller Still Owns

- VPC
- subnet selection
- optional shared security group
- optional shared IAM role
- optional shared KMS key
- optional shared EC2 key pair
- shared tags or naming context

The module family does not own base infrastructure by default.

## Current Internal Shape

The repo now has a shared internal EC2 host/bootstrap path used by both public and private variants. That internal layer owns:

- identity resolution
- exposure resolution
- resource naming/tag application
- IAM/KMS/SG resolution
- instance and block device defaults
- user-data rendering
- normalized output construction

This helper layer is intentionally internal. The public contract remains at the service-module level.

## Verification Baseline

On Node 20, the expected local verification path is:

```bash
npm run verify
```

That should cover:

- TypeScript compile
- Jest tests
- jsii/Go packaging

## Tracked Baseline

The tracked git history now starts from a real milestone sequence rather than a compacted initial baseline.

Current tracked milestones:

- scaffold and package baseline
- tracked README and maintainer setup
- shared contracts plus public/private EC2 service family
- exposure controls and operational hooks
- consumer app CI/CD scaffolding
- in-repo consumer proof for both public and private postures

Tracked package version is now `0.0.6`.

## Current Role In The Workspace

This repo is the active implementation repo.

Use `ec2-assignment` as the shared Terraform/Packer infra repo for the same service model.
Use `smallcase-go-service` as the Go application repo with both consumer infra paths.
Use this repo for reusable CDK module evolution around that same service shape.
