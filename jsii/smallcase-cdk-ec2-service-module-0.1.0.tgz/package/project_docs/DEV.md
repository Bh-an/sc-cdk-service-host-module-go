# Developer Workflow

This document is the local maintainer guide for `cdk-ec2-service-module`.

Use `project_docs/README.md` for architecture and current repo role.
Use this file for day-to-day development, verification, and guardrail alignment.

## Guardrail Alignment

This repo uses local-only agent and documentation files:

- `AGENTS.md`
- `CLAUDE.md`
- `.setup/`
- `project_docs/`

Those must stay excluded through `.git/info/exclude`, not `.gitignore`.

The committed `.gitignore` should only cover real project artifacts such as:

- `node_modules/`
- `dist/`
- `lib/`
- `cdk.out/`
- `.jsii`
- `*.tgz`

## Local Environment

- preferred Node version: `20`
- supported Node versions: `20`, `22`, `24`
- avoid Node `25` for normal verification

Repo-local markers:

- `.nvmrc`
- `.node-version`

## Standard Maintainer Loop

```fish
cd /home/bhan/smallcase/cdk-ec2-service-module
nvm use 20
npm ci
npm run verify
```

`verify` is the pre-commit and pre-release baseline.

Current tracked package version:

- `0.0.6`

## Packaging Notes

The packaging path relies on:

- `jsii`
- `jsii-pacmak`
- `tools/npm-pack.sh`

The package flow isolates npm and Go cache paths under `/tmp` so local home-directory cache ownership does not derail verification.

The repo now also tracks:

- a root `README.md` for jsii packaging metadata
- consumer CI/CD reference material under `docs/` and `.github/workflow-templates/`
- an in-repo consumer proof example under `examples/consumer-proof-stack.ts`
- a Go-app-oriented consumer workflow template

## Current Repo Expectations

When changing the CDK service family:

- keep the assignment service model intact
- expand on the infra/devops side, not the application/runtime side
- preserve additive public APIs unless there is a clear migration reason
- prefer shared internal helpers before copying EC2 host/bootstrap logic
- treat `.jsii` as generated output, not as source

## Before A Commit

Run:

```fish
npm run verify
```

Then sanity-check:

- changed examples still synthesize through the test suite
- public contracts still package through jsii
- local docs in `project_docs/` still match the actual repo state
- consumer integration docs still match the current exported module behavior
