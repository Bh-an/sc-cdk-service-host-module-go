import { aws_ec2 as ec2, aws_iam as iam, aws_kms as kms } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { NetworkAddressableServiceOutputs, PlatformServiceProps, ResolvedPlatformServiceIdentity, ServiceExposureKind } from '../contracts/platform-service';
import { IngressRule, ServiceHostRuntimeProps } from './types';
interface ServiceHostDefaults {
    readonly associatePublicIpAddress: boolean;
    readonly defaultIngressRules: IngressRule[];
    readonly exposureKind: ServiceExposureKind;
    readonly enableElasticIp: boolean;
}
export interface ServiceHostProps extends PlatformServiceProps, ServiceHostRuntimeProps, ServiceHostDefaults {
}
export interface ServiceHostResources {
    readonly dataKey: kms.IKey;
    readonly dataMountPath: string;
    readonly dataVolumeDeviceName: string;
    readonly elasticIp?: ec2.CfnEIP;
    readonly instance: ec2.Instance;
    readonly role: iam.IRole;
    readonly securityGroup: ec2.ISecurityGroup;
    readonly serviceIdentity: ResolvedPlatformServiceIdentity;
    readonly serviceOutputs: NetworkAddressableServiceOutputs;
}
export interface ResolveServiceHostExposureOptions {
    readonly defaultExposureKind: ServiceExposureKind;
    readonly legacyAssociatePublicIpAddress: boolean;
    readonly legacyDefaultIngressRules: IngressRule[];
    readonly legacyEnableElasticIp: boolean;
    readonly privateVpcCidr: string;
    readonly publicPort: number;
    readonly requestedExposure?: ServiceHostRuntimeProps['exposure'];
}
export declare function resolveServiceHostExposure(options: ResolveServiceHostExposureOptions): ServiceHostDefaults;
export declare function createServiceHostResources(scope: Construct, props: ServiceHostProps): ServiceHostResources;
export {};
