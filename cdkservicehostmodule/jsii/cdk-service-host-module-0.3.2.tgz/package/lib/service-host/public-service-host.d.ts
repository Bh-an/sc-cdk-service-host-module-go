import { aws_ec2 as ec2, aws_iam as iam, aws_kms as kms } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { NetworkAddressableServiceOutputs, PlatformServiceProps, ResolvedPlatformServiceIdentity } from '../contracts/platform-service';
import { ServiceHostRuntimeProps } from './types';
export type { IngressRule } from './types';
export interface PublicServiceHostProps extends PlatformServiceProps, ServiceHostRuntimeProps {
    readonly enableElasticIp?: boolean;
}
export declare class PublicServiceHost extends Construct {
    readonly dataKey: kms.IKey;
    readonly dataMountPath: string;
    readonly dataVolumeDeviceName: string;
    readonly elasticIp?: ec2.CfnEIP;
    readonly instance: ec2.Instance;
    readonly role: iam.IRole;
    readonly securityGroup: ec2.ISecurityGroup;
    readonly serviceIdentity: ResolvedPlatformServiceIdentity;
    readonly serviceOutputs: NetworkAddressableServiceOutputs;
    constructor(scope: Construct, id: string, props: PublicServiceHostProps);
}
