export declare const DEFAULT_NGINX_CONF: string;
export declare function buildDefaultAppRoutesConfig(host: string, port: number, publicPort: number): string;
