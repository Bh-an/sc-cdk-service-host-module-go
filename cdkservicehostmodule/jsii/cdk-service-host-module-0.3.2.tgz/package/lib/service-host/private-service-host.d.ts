import { aws_ec2 as ec2, aws_iam as iam, aws_kms as kms } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { NetworkAddressableServiceOutputs, PlatformServiceProps, ResolvedPlatformServiceIdentity } from '../contracts/platform-service';
import { ServiceHostRuntimeProps } from './types';
export interface PrivateServiceHostProps extends PlatformServiceProps, ServiceHostRuntimeProps {
}
export declare class PrivateServiceHost extends Construct {
    readonly dataKey: kms.IKey;
    readonly dataMountPath: string;
    readonly dataVolumeDeviceName: string;
    readonly elasticIp?: ec2.CfnEIP;
    readonly instance: ec2.Instance;
    readonly role: iam.IRole;
    readonly securityGroup: ec2.ISecurityGroup;
    readonly serviceIdentity: ResolvedPlatformServiceIdentity;
    readonly serviceOutputs: NetworkAddressableServiceOutputs;
    constructor(scope: Construct, id: string, props: PrivateServiceHostProps);
}
