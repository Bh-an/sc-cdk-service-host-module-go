# Current State

## Summary

`sc-cdk-service-host-module` is the source-of-truth CDK repo for the shared service-host module family.

Current tracked release:

- `0.2.0-dev`

Current working branch and target:

- branch: `dev`
- next package/release target: `0.2.0`

## Current Modules

- `Ec2DockerService`
  - public/default posture
  - module-managed public endpoint by default
- `PrivateEc2DockerService`
  - private/internal posture
  - no module-managed public endpoint by default

Both variants share:

- caller-owned infra contracts
- identity and naming resolution
- normalized outputs
- exposure metadata
- ingress via CIDR or source security group
- operational hooks for IAM and bootstrap behavior

## Verification

Primary maintainer gate:

```bash
npm run verify
```

This now passes on the supported Node 20 path.

## Workspace Relationship

- `sc-tf-service-host-module`
  - Terraform/Packer counterpart for the same runtime model
- `sc-cdk-service-host-module-go`
  - generated Go wrapper repo for published Go consumption
- `sc-ec2-go-service`
  - consumer Go service repo using published/shared repos instead of local sibling-only paths

## Known Notes

- `.jsii` is treated as generated output
- local-only docs need to stay aligned with the tracked `0.2.0-dev` state
- real published GitHub URLs are now part of the consumer contract; local sibling rewrites are only for local validation
- current deployability contract assumes the GHCR package is public unless registry auth is added later
