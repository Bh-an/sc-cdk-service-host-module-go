# Governance

Local rules for `sc-cdk-service-host-module`:

- tracked docs are consumer-facing and release-facing
- local `project_docs/` may use sibling paths, but must match the tracked `0.2.0-dev` state
- cross-repo references in tracked docs should use GitHub URLs
- release updates must keep:
  - `README.md`
  - `docs/consumer-cicd.md`
  - workflow templates
  - local trackers
  in sync
