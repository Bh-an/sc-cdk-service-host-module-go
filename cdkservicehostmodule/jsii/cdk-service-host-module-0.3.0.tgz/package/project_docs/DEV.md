# Developer Workflow

This document is the local maintainer guide for `sc-cdk-service-host-module`.

Use `project_docs/README.md` for architecture and repo role. Use this file for development and verification.

## Guardrails

Local-only files stay excluded through `.git/info/exclude`:

- `AGENTS.md`
- `CLAUDE.md`
- `.setup/`
- `project_docs/`

Tracked `.gitignore` only covers real project artifacts such as:

- `node_modules/`
- `dist/`
- `lib/`
- `cdk.out/`
- `.jsii`
- `*.tgz`

## Local Environment

- preferred Node version: `20`
- supported Node versions: `20`, `22`, `24`
- avoid Node `25` for normal verification

Repo-local version markers:

- `.nvmrc`
- `.node-version`

## Maintainer Loop

```fish
cd ../sc-cdk-service-host-module
nvm use 20
npm ci
npm run verify
```

Current tracked package version:

- `0.2.0-dev`

## Packaging Notes

The packaging path relies on:

- `jsii`
- `jsii-pacmak`
- `tools/npm-pack.sh`

Consumer-facing tracked materials now include:

- root `README.md`
- `docs/consumer-cicd.md`
- `.github/workflow-templates/consumer-app-deploy-go-cdk.yml`
- `.github/workflow-templates/consumer-app-deploy-terraform.yml`

## Before A Commit

Run:

```fish
npm run verify
```

Then sanity-check:

- changed examples still synthesize through the test suite
- public contracts still package through jsii
- local docs in `project_docs/` still match the tracked `0.2.0-dev` state
