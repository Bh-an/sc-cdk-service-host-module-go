# Decisions

Local architecture history for `sc-cdk-service-host-module`.

## Current Defaults

- TypeScript CDK remains the implementation source of truth
- Go bindings are generated in a separate wrapper repo
- caller-owned infrastructure remains the module boundary
- runtime model stays assignment-aligned
- current shared release line is `v0.3.0`
- current public constructs are:
  - `PublicServiceHost`
  - `PrivateServiceHost`

## Important Decisions

1. Keep the EC2 + Docker + Nginx runtime model as the behavioral baseline.
2. Keep this repo focused on the reusable CDK module only.
3. Use TS-to-Go via jsii rather than maintaining native Go implementation logic here.
4. Plug into caller-owned infra instead of creating full platform foundations.
5. Generalize repo/module identity before broader abstraction.
6. In `v0.3.0`, perform the breaking public API rename from `Ec2*` to `ServiceHost*`.
7. Future releases should be tag-driven from `main` via GitHub Actions.
8. Node `22` is the preferred local and CI path while keeping support for `20`, `22`, and `24`.
9. CI/CD-only changes should use a short-lived `ci-cd` branch rather than `dev`.
