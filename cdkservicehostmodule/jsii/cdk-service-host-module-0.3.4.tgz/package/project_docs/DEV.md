# Developer Workflow

Local maintainer guide for `sc-cdk-service-host-module`.

## Environment

- preferred Node: `22`
- supported Node: `20`, `22`, `24`

## Maintainer Loop

```bash
nvm use 22
npm ci
npm run verify
```

## Current Release Baseline

- branch: `dev`
- package version: `0.3.0`
- local docs baseline: `v0.3.0`

## Before A Commit

- run `npm run verify`
- ensure local docs still match the tracked `v0.3.0` state
