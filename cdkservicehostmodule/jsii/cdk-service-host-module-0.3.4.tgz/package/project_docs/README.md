# sc-cdk-service-host-module

Local tracker for the shared CDK source repo.

## Role

- TypeScript/jsii source of truth for the shared service-host module
- publishes TypeScript artifacts from this repo
- generates Go bindings into the sibling wrapper repo

## Current Public Surface

- `PublicServiceHost`
- `PrivateServiceHost`
- shared contracts from `src/contracts/platform-service.ts`
- runtime/config types from `src/service-host/types.ts`

## Current Release State

- working branch: `dev`
- current published line: `v0.3.0`
- service repo owns the fresh-machine operator surface via root scripts and `make` targets
- service repo `TESTING.md` is the real-account testing runbook

## Verification Baseline

```bash
nvm use 22
npm run verify
```

## Related Repos

- `../sc-cdk-service-host-module-go`
- `../sc-tf-service-host-module`
- `../sc-ec2-go-service`
