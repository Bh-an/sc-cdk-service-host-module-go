# API

Local API orientation note for `sc-cdk-service-host-module`.

## Main Exports

- `PlatformServiceIdentity`
- `ServiceInfrastructureProps`
- `PlatformServiceProps`
- `ResolvedPlatformServiceIdentity`
- `PlatformServiceOutputs`
- `NetworkAddressableServiceOutputs`
- `ServiceExposureKind`
- `mergeTags`
- `applyTags`
- `resolveServiceIdentity`
- `buildResourceName`
- `PublicServiceHost`
- `PrivateServiceHost`
- `PublicServiceHostProps`
- `PrivateServiceHostProps`
- `ServiceHostRuntimeProps`
- `ServiceHostOperationalControls`
- `ServiceHostExposure`
- `IngressRule`

## Notes

- `PublicServiceHost` is the public/default posture
- `PrivateServiceHost` is the private/internal posture
- caller-owned infra remains the boundary
- runtime model is still EC2 host + Dockerized Go app + host Nginx
