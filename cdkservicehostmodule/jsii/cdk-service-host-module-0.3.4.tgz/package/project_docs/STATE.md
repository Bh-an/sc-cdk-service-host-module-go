# Current State

## Summary

`sc-cdk-service-host-module` is the shared CDK source repo for the service-host module family.

## Release State

- active branch: `dev` (`0684e80`) — docs-only, ahead of `main`
- `main`: `2ca7ecd` — active release baseline
- current published tag: `v0.3.3` (points to `2ca7ecd`)
- PR #4 open: `dev` → `main` (`docs: final documentation polish`)

## Current Module Surface

- `PublicServiceHost` — internet-facing, module-managed EIP
- `PrivateServiceHost` — VPC-internal, no public endpoint
- Release automation under `.github/workflows/release.yml`
- Tag-driven release model from `main`

## Tracked Docs (current)

- `README.md` — construct hierarchy diagram, `> [!IMPORTANT]` defaults governance, live-verified note at release, `docs/*` convention
- `CONTRIBUTING.md` — `> [!NOTE]` pending branch protection, `docs/*` branch row

## Verified

- `npm test -- --runInBand`
- `npm run package:go`
- v0.3.3 consumed live by `sc-ec2-go-service` public CDK path (2026-03-27)

## Notes

- Generated Go bindings are published to `sc-cdk-service-host-module-go`
- Old `Ec2*` public API names were removed; current public API is `PublicServiceHost` / `PrivateServiceHost`
