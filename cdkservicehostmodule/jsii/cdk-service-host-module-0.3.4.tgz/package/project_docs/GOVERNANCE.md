# Governance

Local rules for `sc-cdk-service-host-module`:

- tracked docs are consumer-facing and release-facing
- local `project_docs/` may use sibling paths, but must match the tracked `v0.3.0` state
- tracked cross-repo references should use GitHub URLs
- release updates must keep `README.md`, `docs/consumer-cicd.md`, workflow templates, and local trackers aligned
- service-operator guidance should point back to `sc-ec2-go-service/TESTING.md` for real-account testing
