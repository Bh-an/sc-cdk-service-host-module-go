# Current State

## Summary

`sc-cdk-service-host-module` is the shared CDK source repo for the service-host module family.

## Release State

- branch: `dev`
- tracked package version: `0.3.0`
- current published tag: `v0.3.0`
- last CI/CD hardening lane used: `ci-cd`

## Current Module Surface

- `PublicServiceHost`
- `PrivateServiceHost`
- release automation now exists under `.github/workflows/release.yml`
- tag-driven release model expects semver tags from `main`

## Verified

- `npm test -- --runInBand`
- `npm run package:go`

## Notes

- old public `Ec2*` names are intentionally removed from the shared API
- generated Go bindings are synced into `../sc-cdk-service-host-module-go`
- local-only docs should stay aligned with the tracked `v0.3.0` state
