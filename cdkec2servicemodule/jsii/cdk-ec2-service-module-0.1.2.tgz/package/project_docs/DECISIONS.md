# Decisions

This file is local-only architecture history for `cdk-ec2-service-module`.

Use it when you need chronology and rationale, not as a quick-start guide.

## Current Defaults

- TypeScript CDK code is the source of truth
- Go bindings are generated and published separately
- the module family plugs into caller-owned infrastructure
- the runtime model stays aligned to the original assignment
- current tracked release is `0.1.0`
- current concrete modules are:
  - `Ec2DockerService`
  - `PrivateEc2DockerService`
- maintainer verification baseline is Node 20 plus `npm run verify`

## Decision 1: Keep the assignment runtime model as the behavioral baseline

The repo preserves the same service shape as the original assignment:

- EC2 host
- Dockerized Go app
- host-level Nginx
- encrypted storage
- SSM-first access

## Decision 2: Build a separate reusable CDK repo instead of extending Terraform in place

The shared CDK module work lives here, not inside the Terraform repo.

## Decision 3: Use TypeScript as the implementation source of truth

This repo follows the smallcase-style TS-to-Go pattern:

- TypeScript implementation here
- generated Go wrapper published separately

## Decision 4: Plug into caller-owned infrastructure

Consumers must provide existing VPC and subnet selection, with optional shared SG, IAM role, KMS key, and key pair.

## Decision 5: Split by reusable behavior, not by Terraform file categories

Public boundaries are service-level contracts and variants, not one construct per AWS service.

## Decision 6: Add shared identity and normalized outputs before broadening the module family

The shared contract layer was added before introducing more service postures so future modules can present a consistent consumer API.

## Decision 7: Expand on the infra/devops axis, not the application/runtime axis

The runtime stays the same; improvements focus on exposure posture, composability, packaging, and operational controls.

## Decision 8: Add a private/internal sibling instead of a new runtime family

`PrivateEc2DockerService` proves reuse without drifting away from the assignment service model.

## Decision 9: Extract a shared internal EC2 host/bootstrap path

IAM, KMS, SG, instance defaults, and bootstrap rendering are shared internally between the public and private variants.

## Decision 10: Normalize milestone history instead of creating a synthetic compact baseline

The tracked history reflects the real implementation sequence instead of flattening the repo into one artificial initial commit.

## Decision 11: Add exposure controls and operational hooks as additive hardening

The service family gained:

- exposure metadata
- CIDR or source-security-group ingress
- IAM extension hooks
- monitoring and bootstrap controls

without changing the runtime model.

## Decision 12: Require the consumer application to be Go

The consumer app repo is now explicitly Go-based. The CDK module remains TS source with generated Go consumption.

## Decision 13: Split the workspace into four repos and publish standalone dependencies

The current workspace shape is:

- `sc-terraform-ec2-service-module`
- `cdk-ec2-service-module`
- `cdk-ec2-service-module-go`
- `ec2-go-service`

This removed the earlier sibling-only coupling and established a standalone `v0.1.0` release model.
