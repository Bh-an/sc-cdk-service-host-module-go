# cdk-ec2-service-module

`cdk-ec2-service-module` is the active shared CDK module repo in the current four-repo split.

It owns the reusable EC2 service constructs for the assignment-aligned runtime shape:

- EC2 host
- Dockerized Go app
- host-level Nginx
- encrypted storage
- SSM-first access posture

## Current Public Surface

The repo currently exposes two concrete service variants:

- `Ec2DockerService`
  - public/default posture
  - module-managed Elastic IP by default
- `PrivateEc2DockerService`
  - private/internal posture
  - no module-managed public endpoint by default

Shared contracts cover:

- caller-owned infrastructure inputs
- service identity and naming
- normalized service outputs
- exposure-kind metadata
- ingress via CIDR or source security group
- operational hooks for IAM extension, detailed monitoring, and bootstrap commands

## Repo Role

Use this repo for shared CDK module evolution only.

Use the sibling repos for the other concerns:

- `../sc-terraform-ec2-service-module`
  - shared Terraform/Packer infra repo
- `../cdk-ec2-service-module-go`
  - generated Go wrapper repo published from this source repo
- `../ec2-go-service`
  - Go application repo with Terraform and Go CDK consumer paths

## Verification Baseline

```bash
cd /home/bhan/smallcase/cdk-ec2-service-module
nvm use 20
npm run verify
```

That covers compile, tests, and jsii/Go packaging.

## Current Tracked State

- tracked package version: `0.1.0`
- standalone consumer guidance is aligned to:
  - Terraform consumers using the standalone Terraform repo
  - Go CDK consumers using the standalone Go wrapper repo
- generated Go artifacts are published through the separate wrapper repo, not consumed from local sibling paths in normal usage
- service-image contract is GHCR-based: `ghcr.io/bh-an/ec2-go-service`
