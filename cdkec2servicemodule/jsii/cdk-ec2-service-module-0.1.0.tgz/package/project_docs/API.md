# API

This is the local API orientation note for `cdk-ec2-service-module`.

It is not meant to replace generated jsii docs. Use it when you need a quick view of the exported surface without regenerating docs.

## Current Exports

From `src/index.ts`, the repo currently exports:

- `PlatformServiceIdentity`
- `ServiceInfrastructureProps`
- `PlatformServiceProps`
- `ResolvedPlatformServiceIdentity`
- `PlatformServiceOutputs`
- `NetworkAddressableServiceOutputs`
- `ServiceExposureKind`
- `mergeTags`
- `applyTags`
- `resolveServiceIdentity`
- `buildResourceName`
- `Ec2DockerService`
- `PrivateEc2DockerService`
- `Ec2DockerServiceRuntimeProps`
- `IngressRule`

## Current Public Shape

### Shared contracts

The shared contracts define:

- caller-owned infrastructure inputs
- service identity and naming resolution
- merged tag behavior
- normalized service outputs
- exposure-kind metadata for network-facing services

### Concrete modules

The repo ships two concrete modules for the same assignment-aligned runtime model:

- `Ec2DockerService`
  - public/default posture
  - Elastic IP by default
- `PrivateEc2DockerService`
  - private/internal posture
  - no public endpoint by default

### Runtime props

`Ec2DockerServiceRuntimeProps` captures runtime and host-bootstrap settings such as:

- Docker image
- ingress rules
- exposure controls
- operational controls
- service and public port selection
- block-device sizing
- Docker bridge settings

## Consumer Integration Note

Tracked consumer integration guidance now lives in:

- `README.md`
- `docs/consumer-cicd.md`
- `.github/workflow-templates/consumer-app-deploy-go-cdk.yml`
- `.github/workflow-templates/consumer-app-deploy-terraform.yml`

Read those as Go-app consumer guidance using:

- the standalone Terraform repo
- the published Go wrapper repo

## Generated API Docs

If you want generated docs from the TypeScript source, run:

```bash
npm run docgen
```
